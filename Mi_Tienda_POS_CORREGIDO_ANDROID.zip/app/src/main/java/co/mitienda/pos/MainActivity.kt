package co.mitienda.pos

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import android.widget.LinearLayout

class MainActivity : Activity() {
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val wv = WebView(this)
            webView = wv
            wv.setBackgroundColor(Color.WHITE)
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.settings.allowFileAccess = true
            wv.settings.allowContentAccess = true
            wv.settings.databaseEnabled = true
            wv.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(message: ConsoleMessage): Boolean {
                    android.util.Log.e("MiTiendaPOS", message.message() + " (línea " + message.lineNumber() + ")")
                    return true
                }
            }
            wv.webViewClient = object : WebViewClient() {
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    super.onReceivedError(view, request, error)
                    if (request.isForMainFrame) showError("No se pudo cargar Mi Tienda POS. Cierra y vuelve a abrir la aplicación.")
                }
            }
            setContentView(wv)
            wv.loadUrl("file:///android_asset/index.html")
        } catch (e: Exception) {
            android.util.Log.e("MiTiendaPOS", "Error al iniciar", e)
            showError("No se pudo iniciar Mi Tienda POS. Código: " + e.javaClass.simpleName)
        } catch (e: Error) {
            android.util.Log.e("MiTiendaPOS", "Error fatal al iniciar", e)
            showError("Error interno al iniciar Mi Tienda POS. Código: " + e.javaClass.simpleName)
        }
    }

    private fun showError(message: String) {
        val text = TextView(this)
        text.text = message
        text.textSize = 18f
        text.setTextColor(Color.DKGRAY)
        text.gravity = Gravity.CENTER
        text.setPadding(32, 32, 32, 32)
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        layout.addView(text, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(layout)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val wv = webView
        if (wv != null && wv.canGoBack()) wv.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
